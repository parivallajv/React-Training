import CampaignTable from "./components/CampaignTable";

function App() {
  return <div className="App" style={{margin:0}}>
    <CampaignTable/>
  </div>;
}

export default App;
