import { ActiveButton } from "../Styles";

const StatusButton = () => {
  return (
    <div>
      <ActiveButton>Active</ActiveButton>
    </div>
  );
};

export default StatusButton;
